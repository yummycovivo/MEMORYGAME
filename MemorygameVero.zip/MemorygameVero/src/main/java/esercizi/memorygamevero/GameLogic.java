/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package esercizi.memorygamevero;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import javax.swing.*;
import javax.swing.Timer;
import java.net.URL;
/**
 *
 * @author yummycovivo
 */
public class GameLogic {
     private JButton[] gButtons = new JButton[6];
    private int gButtonsClicked = 0;
    private boolean gGameWon = false;
    private JButton firstButton;
    private JButton secondButton;
    ImageIcon ICON_DESCRIPTION1, ICON_DESCRIPTION2;
    
    public GameLogic(JButton[] buttons) {
        this.gButtons = buttons;
        InitializeButtons();
        SetAllButtonsDEFAULT();
    }
    
    
    public void SetAllButtonsDEFAULT(){
        for(int i = 0;i<gButtons.length;i++){
            gButtons[i].setBackground(Color.BLACK);
            gButtons[i].setText(null);
        }
    }
    
    public void InitializeButtons(){
        String[] imageURLs = {"/resources/ciliega.png","/resources/ciliega.png"
                            , "/resources/mela.png", "/resources/mela.png"
                            , "/resources/banana.png", "/resources/banana.png"
                            /*, "/resources/gomma.png", "/resources/gomma.png"
                            , "/resources/alarme.png", "/resources/alarme.png"
                            , "/resources/tacchi.png", "/resources/tacchi.png"*/};
        
        ArrayList<String> List = new ArrayList<>(Arrays.asList(imageURLs));
        Collections.shuffle(List);
        
        for (int i = 0; i < gButtons.length; i++) {
            ImageIcon icon = new ImageIcon(getClass().getResource(List.get(i)));
            gButtons[i].setIcon(icon);
        }
    }
    
    public void ButtonClicked(int buttonN){
        JButton clickedButton = gButtons[buttonN];
        
        clickedButton.setBackground(Color.WHITE);
        clickedButton.setForeground(Color.WHITE);
        
        if(gButtonsClicked==0){
            firstButton=gButtons[buttonN];
            ICON_DESCRIPTION1 = (ImageIcon) firstButton.getIcon();
            
            gButtonsClicked=1;
        }else if(gButtonsClicked==1){
            secondButton=gButtons[buttonN];
            if(secondButton==firstButton){
                gButtonsClicked=1;
            }else{
            gButtonsClicked=2;
            ICON_DESCRIPTION2 = (ImageIcon) secondButton.getIcon();
            CheckForMatch();
            } 
        }
    }
    
    public void CheckForMatch(){
        if(ICON_DESCRIPTION1.getDescription().equals(ICON_DESCRIPTION2.getDescription())){
            firstButton.setEnabled(false);
            secondButton.setEnabled(false);
            SelectionReset();
        }else{
            System.out.println("Non uguale");
            Timer timer = new Timer(250, e -> {
                resetButton(firstButton);
                resetButton(secondButton);
                SelectionReset();
                });
            timer.setRepeats(false);
            timer.start();
        }
    }
    
    public void SelectionReset(){
        firstButton = null;
        secondButton = null;
        gButtonsClicked = 0;
        
        for(int i=0;i<gButtons.length;i++){
            if(gButtons[i].getBackground() == Color.BLACK){
                gButtons[i].setVisible(false);
            }
        }
    }
    
    private void resetButton(JButton button) {
        button.setBackground(Color.BLACK);
        button.setForeground(button.getBackground()); 
    }
}
